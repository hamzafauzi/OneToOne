<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Laravel App</title>
    <!-- Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add Students
                            <a href="<?php echo e(url ('students')); ?>" class="btn btn-primary float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(url('students')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <h4>Students</h4>
                            <div class="mb-3">
                                <label>Full name</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label>Email</label>
                                <input type="text" name="email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label>Phone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="row">
                                <h4>Student Details</h4>
                                <div class="mb-3 col-md-4">
                                    <label>Alternate Phone</label>
                                    <input type="text" name="alternate_phone" class="form-control" />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label>Course</label>
                                    <input type="text" name="course" class="form-control" />
                                </div>
                                <div class="mb-3 col-md-4">
                                    <label>Roll No.</label>
                                    <input type="text" name="roll_no" class="form-control" />
                                </div>
                                <div class="mb-3 col-md-12">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS scripts (place them before the closing body tag) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\Student\resources\views/student/create.blade.php ENDPATH**/ ?>